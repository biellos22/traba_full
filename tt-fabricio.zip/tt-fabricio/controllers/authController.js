const User = require('../models/userModel');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    try {
        const { username, email, password } = req.body;
        await user.save();
        res.status(201).json({message: 'Usuário cadastrado'});
       
    } catch (error) {
        res.status(500).json({error: error.massage});
    }
};

exports.login = async (req, res) => {
    try {
        const {email, password } = req.body;
        const user = await User.findOne({ email });
        if (!user || !(await user.comparePassword(password))) {
            return res.status(400).json({ message: 'Credenciais inválidas'});     
        }
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {expiresIn: '1h'});
        res.json({ token });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

