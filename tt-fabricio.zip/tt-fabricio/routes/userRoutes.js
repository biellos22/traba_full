const express = require('express');
const { getUsers, updateUser, deleteUser } = require('../controllers/userController');
const router = express.Router();

router.use(require('../controllers/userController').authenticate);

router.get('/', getUsers);
router.put('/', updateUser);
router.delete('/', deleteUser);

module.exports = router;
